#include "config.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void set_default_config(AppConfig* cfg) {
    if (!cfg) return;
    snprintf(cfg->matrix_dir, sizeof(cfg->matrix_dir), "matrices");
    cfg->pool_size = 8;  // Match typical CPU core count (4-8 cores common)
    cfg->pool_idle_sec = 60;
    cfg->pool_max_tasks = 1000;
    cfg->enable_menu_reorder = 0;
    cfg->preload_count = 0;
    
    // Default menu order (1-15 in sequence)
    cfg->menu_order_count = 0;
    for (int i = 0; i < CONFIG_MAX_MENU_ITEMS; i++) {
        cfg->menu_order[i] = i + 1;
    }
}

static void trim(char* s) {
    if (!s) return;
    size_t n = strlen(s);
    while (n && isspace((unsigned char)s[n-1])) s[--n] = '\0';
    char* p = s;
    while (*p && isspace((unsigned char)*p)) p++;
    if (p != s) memmove(s, p, strlen(p)+1);
}

int load_config(const char* path, AppConfig* cfg) {
    if (!path || !cfg) return -1;
    FILE* f = fopen(path, "r");
    if (!f) return -1;

    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        trim(line);
        if (line[0] == '#' || line[0] == '\0') continue;
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = '\0';
        char* key = line;
        char* value = eq + 1;
        trim(key);
        trim(value);

        if (strcmp(key, "matrix_dir") == 0) {
            snprintf(cfg->matrix_dir, sizeof(cfg->matrix_dir), "%s", value);
        } else if (strcmp(key, "pool_size") == 0) {
            cfg->pool_size = atoi(value);
        } else if (strcmp(key, "pool_idle_sec") == 0) {
            cfg->pool_idle_sec = atoi(value);
        } else if (strcmp(key, "pool_max_tasks") == 0) {
            cfg->pool_max_tasks = atoi(value);
        } else if (strcmp(key, "enable_menu_reorder") == 0) {
            cfg->enable_menu_reorder = atoi(value);
        } else if (strcmp(key, "menu_order") == 0) {
            // Parse comma-separated list of integers
            cfg->menu_order_count = 0;
            char* token = strtok(value, ",");
            while (token && cfg->menu_order_count < CONFIG_MAX_MENU_ITEMS) {
                trim(token);
                int option = atoi(token);
                if (option >= 1 && option <= 15) {
                    cfg->menu_order[cfg->menu_order_count++] = option;
                }
                token = strtok(NULL, ",");
            }
        } else if (strcmp(key, "preload") == 0) {
            if (cfg->preload_count < CONFIG_MAX_PRELOAD) {
                snprintf(cfg->preload_files[cfg->preload_count], 256, "%s", value);
                cfg->preload_count++;
            }
        }
    }

    fclose(f);
    return 0;
}
