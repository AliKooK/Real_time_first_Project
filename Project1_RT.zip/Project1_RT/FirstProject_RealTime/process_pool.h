#ifndef PROCESS_POOL_H
#define PROCESS_POOL_H

#include <sys/types.h>
#include <time.h>

/* Job types for worker pool */
typedef enum {
    JOB_NONE = 0,
    JOB_ADD_ELEMENT,
    JOB_SUBTRACT_ELEMENT,
    JOB_MULTIPLY_DOT,
    JOB_ADD_ROW_CHUNK,       // Process multiple rows at once
    JOB_SUBTRACT_ROW_CHUNK,
    JOB_MULTIPLY_ROW_CHUNK,
    JOB_DETERMINANT_ROW_UPDATE,  // Gaussian elimination row update
    JOB_EIGEN_ITERATION,
    JOB_EXIT
} JobType;

/* Job descriptor sent to worker */
typedef struct {
    JobType type;
    int data_size;          // Size of payload in bytes
    int extra_info[4];      // For chunk info: [start_row, end_row, cols, etc]
    double data[16];        // Inline data for small jobs (up to 16 doubles)
    // Optional shared-memory fields for large jobs (e.g., row-chunk matmul)
    // POSIX shm object names must begin with '/'
    char shm_name_a[64];    // input A (e.g., left matrix)
    char shm_name_b[64];    // input B (e.g., right matrix)
    char shm_name_out[64];  // output matrix
    // Dimensions for row-chunk work
    int rows;               // total rows of output (and A)
    int cols;               // total cols of output (and B)
    int inner;              // inner dimension (A.cols == B.rows)
    int start_row;          // inclusive
    int end_row;            // exclusive
} JobDescriptor;

/* Result from worker */
typedef struct {
    int success;
    int data_size;
    double data[16];        // Inline result data
} JobResult;

/* Worker state */
typedef enum {
    WORKER_IDLE = 0,
    WORKER_BUSY,
    WORKER_DEAD
} WorkerState;

/* Individual worker metadata */
typedef struct {
    pid_t pid;
    int pipe_to_worker[2];      // Parent writes job here
    int pipe_from_worker[2];    // Parent reads result here
    WorkerState state;
    time_t last_used;
    int task_count;
} Worker;

/* Worker pool structure */
typedef struct {
    Worker* workers;
    int num_workers;
    int max_idle_seconds;
    int max_tasks_per_worker;
    int shutdown_flag;
} WorkerPool;

/* Pool management functions */
WorkerPool* create_worker_pool(int num_workers, int max_idle_sec, int max_tasks);
void destroy_worker_pool(WorkerPool* pool);

/* Job submission - blocks until job completes */
int submit_job(WorkerPool* pool, const JobDescriptor* job, JobResult* result);

/* Batch submission - distributes jobs across available workers */
int submit_job_batch(WorkerPool* pool, const JobDescriptor* jobs, int job_count, JobResult* results);

/* Pool maintenance */
void check_worker_health(WorkerPool* pool);
void age_idle_workers(WorkerPool* pool);
int respawn_worker(WorkerPool* pool, int worker_idx);

/* Utility */
int get_idle_worker(WorkerPool* pool);
void mark_worker_idle(WorkerPool* pool, int worker_idx);
void mark_worker_busy(WorkerPool* pool, int worker_idx);

#endif // PROCESS_POOL_H
