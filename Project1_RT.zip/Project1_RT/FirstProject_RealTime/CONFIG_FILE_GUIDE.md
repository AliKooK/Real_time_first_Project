# Configuration File Guide

## Overview
The matrix operations program supports loading configuration settings from a text file at startup. This eliminates the need to re-enter settings like matrix directory paths every time you run the program.

## Usage

### Basic Usage
```bash
./menu_demo_v2 config.txt
```

### Without Config File
```bash
./menu_demo_v2
```
If no config file is provided, the program uses default settings.

## Config File Format

The config file uses a simple `key=value` format with one setting per line.

### Example: `config.txt`
```
# Matrix Operations Configuration File
# Lines starting with '#' are comments

# Directory where matrices are stored (used by load/save operations)
matrix_dir=matrices

# Worker pool size (number of persistent child processes)
# Recommended: Match your CPU core count (use 'nproc' to check)
pool_size=8

# Worker idle timeout in seconds (retire workers after this period of inactivity)
pool_idle_sec=60

# Maximum tasks per worker (retire and respawn after this many jobs)
pool_max_tasks=1000

# Menu order customization (0 = default order, 1 = custom order)
# Note: Custom menu ordering is not yet fully implemented
enable_menu_reorder=0
```

## Supported Settings

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `matrix_dir` | string | `"matrices"` | Directory path where matrix files are stored. Used by options 5, 6, 7, 8 in the menu. |
| `pool_size` | integer | `8` | Number of worker processes in the persistent pool. Recommended to match CPU cores. |
| `pool_idle_sec` | integer | `60` | Idle timeout in seconds. Workers are retired after this many seconds of inactivity. |
| `pool_max_tasks` | integer | `1000` | Maximum tasks per worker. Workers are retired and respawned after completing this many jobs to prevent aging issues. |
| `enable_menu_reorder` | integer | `0` or `1` | Enable custom menu ordering. Set to 1 to use custom `menu_order`. |
| `menu_order` | comma-separated integers | `1,2,3,...,15` | Custom menu display order. Example: `10,11,12,1,2,3,4,5,6,7,8,9,13,14,15` |
| `preload` | string | (none) | Matrix file to preload at startup. Can have multiple `preload=` lines. |

## Key Features

### Matrix Directory
The `matrix_dir` setting specifies where matrix files are loaded from and saved to:
- **Default**: `matrices/` subdirectory
- **Custom**: Any relative or absolute path
- **Used by**: Menu options 5 (Read Matrix from File), 6 (Write Matrix to File), 7 (Determinant from File), 8 (Eigenvalues from File)

**Example**:
```
matrix_dir=/home/user/my_matrices
```

### Worker Pool Configuration
The worker pool settings control the persistent multiprocessing architecture:

- **pool_size**: More workers = more parallelism, but higher memory overhead
  - Use `nproc` command to see your CPU core count
  - Typical values: 4-16
  
- **pool_idle_sec**: Prevents workers from consuming resources indefinitely when idle
  - Typical values: 30-300 seconds
  
- **pool_max_tasks**: Prevents memory leaks or aging issues in long-running workers
  - Typical values: 500-5000 tasks

### Menu Reordering
Customize the menu display order to group related operations:

**How to use:**
1. Set `enable_menu_reorder=1`
2. Define `menu_order` with comma-separated option numbers
3. Menu displays in your custom order

**Example: Operations-first layout**
```
enable_menu_reorder=1
menu_order=10,11,12,13,14,1,2,3,4,9,5,6,7,8,15
```

This displays:
- Operations (10-14) first: Add, Subtract, Multiply, Determinant, Eigenvalues
- Matrix management (1-4,9): Enter, Display, Delete, Modify, Show all
- File I/O (5-8): Read/Write files and folders
- Exit (15) last

**Workflow-based layouts:**
- **Data Analysis**: `5,6,9,13,14,10,11,12,2,7,8,1,3,4,15`
- **Quick Operations**: `10,11,12,9,2,1,3,4,5,6,7,8,13,14,15`
- **File Management**: `5,6,7,8,9,1,2,3,4,10,11,12,13,14,15`

### Matrix Preloading
Automatically load matrices at startup to avoid manual loading:

**How to use:**
Add multiple `preload=` lines with filenames (relative to `matrix_dir`):
```
preload=Matrix_A.txt
preload=Matrix_B.txt
preload=Identity_3x3.txt
```

All specified matrices are loaded into memory when the program starts, ready for immediate operations.

## File Format Rules

1. **One setting per line**: `key=value`
2. **No spaces around `=`**: ✅ `matrix_dir=matrices` ✗ `matrix_dir = matrices`
3. **Comments**: Lines starting with `#` are ignored
4. **Blank lines**: Ignored
5. **Case-sensitive**: Use exact key names as documented
6. **Unknown keys**: Silently ignored (no error)
7. **Multiple values**: Use multiple lines for `preload=` settings

## Default Configuration

If no config file is provided, these defaults are used:

```c
matrix_dir = "matrices"
pool_size = 8
pool_idle_sec = 60
pool_max_tasks = 1000
enable_menu_reorder = 0
menu_order = 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
preload = (none)
```

## Example Configurations

### Example 1: Default (config.txt)
```
matrix_dir=matrices
pool_size=8
enable_menu_reorder=0
preload=Matrix_A.txt
preload=Matrix_B.txt
```

### Example 2: Operations-First (config_custom_menu.txt)
```
matrix_dir=matrices
pool_size=8
enable_menu_reorder=1
menu_order=10,11,12,13,14,1,2,3,4,9,5,6,7,8,15
preload=Identity_3x3.txt
preload=TestEigen.txt
```

### Example 3: High-Performance
```
matrix_dir=/fast/ssd/matrices
pool_size=16
pool_idle_sec=30
pool_max_tasks=5000
enable_menu_reorder=0
```

## Testing Your Config

1. Create `config.txt` with your settings
2. Run: `./menu_demo_v2 config.txt`
3. Verify preloaded matrices: Use option 9 to display all matrices
4. Check menu order: Look at the menu display
5. Test operations: Select any option to verify functionality

## Troubleshooting

**Problem**: "Failed to load config file: config.txt"
- **Solution**: Ensure the file exists in the current directory or provide full path

**Problem**: Matrix files not found when using option 5/6/7/8
- **Solution**: Verify `matrix_dir` points to the correct location
- **Check**: `ls matrices/` or `ls <your_matrix_dir>/` to confirm files exist

**Problem**: Pool operations seem slow
- **Solution**: Increase `pool_size` to match your CPU cores
- **Check**: Run `nproc` to see available cores

**Problem**: Workers stay alive too long after program use
- **Solution**: Decrease `pool_idle_sec` (e.g., change from 60 to 30)

## Advanced: Custom Matrix Directory Structure

You can organize matrices in subdirectories:

```
my_matrices/
├── tests/
│   ├── Matrix_A.txt
│   └── Matrix_B.txt
├── benchmarks/
│   ├── Large_100.txt
│   └── Large_1000.txt
└── Identity_3x3.txt
```

Config file:
```
matrix_dir=my_matrices/tests
```

When using option 5, just enter the filename (not the full path):
- Input: `Matrix_A.txt`
- Program loads: `my_matrices/tests/Matrix_A.txt`

## Project Compliance

This feature satisfies the project requirement:

> "Allow users to create a text file that contains a directory where matrices can be loaded from... This will help users avoid having to input the directory each time. Users will customize the way users wish to see the menu list. Give the file name as an argument."

✅ Config file passed as command-line argument  
✅ Matrix directory customization  
✅ Avoids re-entering data  
✅ Menu reorder key defined (implementation optional)
