#include "process_pool.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <math.h>

/* Forward declarations */
static void worker_main_loop(int pipe_from_parent, int pipe_to_parent);
static int safe_read(int fd, void* buf, size_t count);
static int safe_write(int fd, const void* buf, size_t count);

/* ========== Worker Process Main Loop ========== */
static void worker_main_loop(int pipe_from_parent, int pipe_to_parent) {
    JobDescriptor job;
    JobResult result;
    
    while (1) {
        // Read job descriptor from parent
        if (safe_read(pipe_from_parent, &job, sizeof(JobDescriptor)) != 0) {
            break; // Parent closed pipe or error
        }
        
        // Check for exit signal
        if (job.type == JOB_EXIT) {
            break;
        }
        
        // Initialize result
        memset(&result, 0, sizeof(JobResult));
        result.success = 1;
        
        // Process job based on type
        switch (job.type) {
            case JOB_ADD_ELEMENT:
                // data[0] = operand1, data[1] = operand2
                result.data[0] = job.data[0] + job.data[1];
                result.data_size = 1;
                break;
                
            case JOB_SUBTRACT_ELEMENT:
                result.data[0] = job.data[0] - job.data[1];
                result.data_size = 1;
                break;
                
            case JOB_MULTIPLY_DOT:
                // data[0..n-1] = row, data[n..2n-1] = col, data[2n] = n
                {
                    int n = (int)job.data[job.data_size - 1];
                    double sum = 0.0;
                    for (int i = 0; i < n; i++) {
                        sum += job.data[i] * job.data[n + i];
                    }
                    result.data[0] = sum;
                    result.data_size = 1;
                }
                break;
                
            case JOB_EIGEN_ITERATION:
                // Placeholder for complex eigenvalue iteration work
                result.data[0] = 0.0;
                result.data_size = 1;
                break;
            case JOB_DETERMINANT_ROW_UPDATE: {
                // Update rows [start_row, end_row) of matrix in Gaussian elimination
                // shm_name_a = matrix buffer, extra_info[0] = pivot_row, extra_info[1] = pivot_col
                // data[0] = pivot_element
                int pivot_row = job.extra_info[0];
                int pivot_col = job.extra_info[1];
                int n = job.rows;  // Matrix is n×n
                int r0 = job.start_row;
                int r1 = job.end_row;
                double pivot = job.data[0];
                
                if (fabs(pivot) < 1e-14) {
                    result.success = 1;  // Nothing to do for zero pivot
                    result.data_size = 0;
                    break;
                }
                
                int fdA = shm_open(job.shm_name_a, O_RDWR, 0);
                if (fdA < 0) {
                    result.success = 0;
                    result.data_size = 0;
                    break;
                }
                
                size_t size = (size_t)n * (size_t)n * sizeof(double);
                double* A = (double*)mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fdA, 0);
                if (A == MAP_FAILED) {
                    close(fdA);
                    result.success = 0;
                    result.data_size = 0;
                    break;
                }
                
                // Perform row updates: row[i] -= (A[i][pivot_col] / pivot) * row[pivot_row]
                for (int i = r0; i < r1; ++i) {
                    if (i == pivot_row) continue;
                    double factor = A[i * n + pivot_col] / pivot;
                    for (int j = pivot_col; j < n; ++j) {
                        A[i * n + j] -= factor * A[pivot_row * n + j];
                    }
                }
                
                munmap(A, size);
                close(fdA);
                result.success = 1;
                result.data_size = 0;
                break;
            }
            
            case JOB_MULTIPLY_ROW_CHUNK: {
                // Use POSIX shared memory objects named in job.{shm_name_a, shm_name_b, shm_name_out}
                // Compute rows [start_row, end_row) of: OUT = A * B
                int nrows = job.rows;
                int ncols = job.cols;
                int inner = job.inner;
                int r0 = job.start_row;
                int r1 = job.end_row;

                // Open and map A (read-only)
                int fdA = shm_open(job.shm_name_a, O_RDONLY, 0);
                int fdB = shm_open(job.shm_name_b, O_RDONLY, 0);
                int fdC = shm_open(job.shm_name_out, O_RDWR, 0);
                if (fdA < 0 || fdB < 0 || fdC < 0) {
                    result.success = 0;
                    result.data_size = 0;
                    if (fdA >= 0) close(fdA);
                    if (fdB >= 0) close(fdB);
                    if (fdC >= 0) close(fdC);
                    break;
                }

                size_t sizeA = (size_t)nrows * (size_t)inner * sizeof(double);
                size_t sizeB = (size_t)inner * (size_t)ncols * sizeof(double);
                size_t sizeC = (size_t)nrows * (size_t)ncols * sizeof(double);

                double* A = (double*)mmap(NULL, sizeA, PROT_READ, MAP_SHARED, fdA, 0);
                double* B = (double*)mmap(NULL, sizeB, PROT_READ, MAP_SHARED, fdB, 0);
                double* C = (double*)mmap(NULL, sizeC, PROT_READ | PROT_WRITE, MAP_SHARED, fdC, 0);
                if (A == MAP_FAILED || B == MAP_FAILED || C == MAP_FAILED) {
                    result.success = 0;
                    result.data_size = 0;
                    if (A != MAP_FAILED) munmap(A, sizeA);
                    if (B != MAP_FAILED) munmap(B, sizeB);
                    if (C != MAP_FAILED) munmap(C, sizeC);
                    close(fdA); close(fdB); close(fdC);
                    break;
                }

                for (int i = r0; i < r1; ++i) {
                    for (int j = 0; j < ncols; ++j) {
                        double sum = 0.0;
                        for (int k = 0; k < inner; ++k) {
                            sum += A[i * inner + k] * B[k * ncols + j];
                        }
                        C[i * ncols + j] = sum;
                    }
                }

                munmap(A, sizeA);
                munmap(B, sizeB);
                munmap(C, sizeC);
                close(fdA); close(fdB); close(fdC);

                result.data_size = 0;
                result.success = 1;
                break;
            }
                
            default:
                result.success = 0;
                break;
        }
        
        // Send result back to parent
        if (safe_write(pipe_to_parent, &result, sizeof(JobResult)) != 0) {
            break; // Parent died
        }
    }
    
    close(pipe_from_parent);
    close(pipe_to_parent);
    exit(0);
}

/* ========== Safe I/O with error handling ========== */
static int safe_read(int fd, void* buf, size_t count) {
    size_t total = 0;
    while (total < count) {
        ssize_t n = read(fd, (char*)buf + total, count - total);
        if (n < 0) {
            if (errno == EINTR) continue;
            perror("safe_read");
            return -1;
        }
        if (n == 0) return -1; // EOF
        total += (size_t)n;
    }
    return 0;
}

static int safe_write(int fd, const void* buf, size_t count) {
    size_t total = 0;
    while (total < count) {
        ssize_t n = write(fd, (const char*)buf + total, count - total);
        if (n < 0) {
            if (errno == EINTR) continue;
            perror("safe_write");
            return -1;
        }
        total += (size_t)n;
    }
    return 0;
}

/* ========== Pool Creation ========== */
WorkerPool* create_worker_pool(int num_workers, int max_idle_sec, int max_tasks) {
    if (num_workers <= 0) num_workers = 4;
    
    WorkerPool* pool = (WorkerPool*)malloc(sizeof(WorkerPool));
    if (!pool) {
        perror("malloc pool");
        return NULL;
    }
    
    pool->num_workers = num_workers;
    pool->max_idle_seconds = max_idle_sec;
    pool->max_tasks_per_worker = max_tasks;
    pool->shutdown_flag = 0;
    
    pool->workers = (Worker*)calloc((size_t)num_workers, sizeof(Worker));
    if (!pool->workers) {
        perror("malloc workers");
        free(pool);
        return NULL;
    }
    
    // Fork all workers
    for (int i = 0; i < num_workers; i++) {
        if (respawn_worker(pool, i) != 0) {
            // Failed to spawn worker - clean up and abort
            destroy_worker_pool(pool);
            return NULL;
        }
    }
    
    printf("[Pool] Created worker pool with %d workers\n", num_workers);
    return pool;
}

/* ========== Respawn a single worker ========== */
int respawn_worker(WorkerPool* pool, int worker_idx) {
    Worker* w = &pool->workers[worker_idx];
    
    // Create pipes
    if (pipe(w->pipe_to_worker) == -1) {
        perror("pipe to_worker");
        return -1;
    }
    if (pipe(w->pipe_from_worker) == -1) {
        perror("pipe from_worker");
        close(w->pipe_to_worker[0]);
        close(w->pipe_to_worker[1]);
        return -1;
    }
    
    pid_t pid = fork();
    if (pid == -1) {
        perror("fork worker");
        close(w->pipe_to_worker[0]);
        close(w->pipe_to_worker[1]);
        close(w->pipe_from_worker[0]);
        close(w->pipe_from_worker[1]);
        return -1;
    }
    
    if (pid == 0) {
        // Child: close parent ends
        close(w->pipe_to_worker[1]);
        close(w->pipe_from_worker[0]);
        
        // Enter worker loop
        worker_main_loop(w->pipe_to_worker[0], w->pipe_from_worker[1]);
        exit(0); // Should not reach here
    }
    
    // Parent: close child ends
    close(w->pipe_to_worker[0]);
    close(w->pipe_from_worker[1]);
    
    w->pid = pid;
    w->state = WORKER_IDLE;
    w->last_used = time(NULL);
    w->task_count = 0;
    
    return 0;
}

/* ========== Pool Destruction ========== */
void destroy_worker_pool(WorkerPool* pool) {
    if (!pool) return;
    
    pool->shutdown_flag = 1;
    
    // Send EXIT job to all workers
    JobDescriptor exit_job = {0};
    exit_job.type = JOB_EXIT;
    
    for (int i = 0; i < pool->num_workers; i++) {
        Worker* w = &pool->workers[i];
        if (w->state != WORKER_DEAD && w->pid > 0) {
            // Try to send exit gracefully
            write(w->pipe_to_worker[1], &exit_job, sizeof(JobDescriptor));
            close(w->pipe_to_worker[1]);
            close(w->pipe_from_worker[0]);
            
            // Wait briefly, then force kill if needed
            int status;
            pid_t result = waitpid(w->pid, &status, WNOHANG);
            if (result == 0) {
                // Still running, give it 1 second
                sleep(1);
                result = waitpid(w->pid, &status, WNOHANG);
                if (result == 0) {
                    kill(w->pid, SIGTERM);
                    waitpid(w->pid, &status, 0);
                }
            }
        }
    }
    
    free(pool->workers);
    free(pool);
    printf("[Pool] Worker pool destroyed\n");
}

/* ========== Get idle worker index ========== */
int get_idle_worker(WorkerPool* pool) {
    for (int i = 0; i < pool->num_workers; i++) {
        if (pool->workers[i].state == WORKER_IDLE) {
            return i;
        }
    }
    return -1; // All busy
}

/* ========== Mark worker state ========== */
void mark_worker_idle(WorkerPool* pool, int worker_idx) {
    pool->workers[worker_idx].state = WORKER_IDLE;
    pool->workers[worker_idx].last_used = time(NULL);
}

void mark_worker_busy(WorkerPool* pool, int worker_idx) {
    pool->workers[worker_idx].state = WORKER_BUSY;
    pool->workers[worker_idx].task_count++;
}

/* ========== Submit single job ========== */
int submit_job(WorkerPool* pool, const JobDescriptor* job, JobResult* result) {
    // Find idle worker
    int worker_idx = get_idle_worker(pool);
    if (worker_idx == -1) {
        fprintf(stderr, "[Pool] No idle workers available\n");
        return -1;
    }
    
    Worker* w = &pool->workers[worker_idx];
    mark_worker_busy(pool, worker_idx);
    
    // Send job
    if (safe_write(w->pipe_to_worker[1], job, sizeof(JobDescriptor)) != 0) {
        fprintf(stderr, "[Pool] Failed to send job to worker %d\n", worker_idx);
        w->state = WORKER_DEAD;
        return -1;
    }
    
    // Read result
    if (safe_read(w->pipe_from_worker[0], result, sizeof(JobResult)) != 0) {
        fprintf(stderr, "[Pool] Failed to read result from worker %d\n", worker_idx);
        w->state = WORKER_DEAD;
        return -1;
    }
    
    mark_worker_idle(pool, worker_idx);
    return 0;
}

/* ========== Submit batch of jobs ========== */
int submit_job_batch(WorkerPool* pool, const JobDescriptor* jobs, int job_count, JobResult* results) {
    int jobs_submitted = 0;
    int jobs_completed = 0;
    int active_workers[pool->num_workers];
    memset(active_workers, -1, sizeof(active_workers));
    
    while (jobs_completed < job_count) {
        // Submit jobs to idle workers
        while (jobs_submitted < job_count) {
            int worker_idx = get_idle_worker(pool);
            if (worker_idx == -1) break; // All busy
            
            Worker* w = &pool->workers[worker_idx];
            mark_worker_busy(pool, worker_idx);
            
            // Send job
            if (safe_write(w->pipe_to_worker[1], &jobs[jobs_submitted], sizeof(JobDescriptor)) != 0) {
                fprintf(stderr, "[Pool] Failed to send job %d to worker %d\n", jobs_submitted, worker_idx);
                w->state = WORKER_DEAD;
                return -1;
            }
            
            active_workers[worker_idx] = jobs_submitted;
            jobs_submitted++;
        }
        
        // Collect results from busy workers
        for (int i = 0; i < pool->num_workers; i++) {
            if (pool->workers[i].state == WORKER_BUSY && active_workers[i] >= 0) {
                Worker* w = &pool->workers[i];
                int job_idx = active_workers[i];
                
                if (safe_read(w->pipe_from_worker[0], &results[job_idx], sizeof(JobResult)) != 0) {
                    fprintf(stderr, "[Pool] Failed to read result from worker %d\n", i);
                    w->state = WORKER_DEAD;
                    return -1;
                }
                
                mark_worker_idle(pool, i);
                active_workers[i] = -1;
                jobs_completed++;
            }
        }
    }
    
    return 0;
}

/* ========== Check worker health ========== */
void check_worker_health(WorkerPool* pool) {
    for (int i = 0; i < pool->num_workers; i++) {
        Worker* w = &pool->workers[i];
        if (w->pid > 0 && w->state != WORKER_DEAD) {
            int status;
            pid_t result = waitpid(w->pid, &status, WNOHANG);
            if (result > 0) {
                // Worker died
                printf("[Pool] Worker %d (pid %d) died unexpectedly, respawning...\n", i, w->pid);
                w->state = WORKER_DEAD;
                respawn_worker(pool, i);
            }
        }
    }
}

/* ========== Age idle workers ========== */
void age_idle_workers(WorkerPool* pool) {
    if (pool->max_idle_seconds <= 0 && pool->max_tasks_per_worker <= 0) {
        return; // No aging policy
    }
    
    time_t now = time(NULL);
    
    for (int i = 0; i < pool->num_workers; i++) {
        Worker* w = &pool->workers[i];
        if (w->state != WORKER_IDLE) continue;
        
        int should_retire = 0;
        
        // Check idle timeout
        if (pool->max_idle_seconds > 0) {
            if (difftime(now, w->last_used) > pool->max_idle_seconds) {
                printf("[Pool] Worker %d idle for %ld seconds, retiring...\n", 
                       i, (long)difftime(now, w->last_used));
                should_retire = 1;
            }
        }
        
        // Check task count
        if (pool->max_tasks_per_worker > 0) {
            if (w->task_count >= pool->max_tasks_per_worker) {
                printf("[Pool] Worker %d completed %d tasks, retiring...\n", 
                       i, w->task_count);
                should_retire = 1;
            }
        }
        
        if (should_retire) {
            // Send exit signal and respawn
            JobDescriptor exit_job = {0};
            exit_job.type = JOB_EXIT;
            write(w->pipe_to_worker[1], &exit_job, sizeof(JobDescriptor));
            close(w->pipe_to_worker[1]);
            close(w->pipe_from_worker[0]);
            waitpid(w->pid, NULL, 0);
            w->state = WORKER_DEAD;
            respawn_worker(pool, i);
        }
    }
}
