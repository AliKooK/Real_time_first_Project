#ifndef CONFIG_H
#define CONFIG_H

#define CONFIG_MAX_PATH 512
#define CONFIG_MAX_PRELOAD 20
#define CONFIG_MAX_MENU_ITEMS 15

typedef struct {
    char matrix_dir[CONFIG_MAX_PATH];
    int pool_size;
    int pool_idle_sec;
    int pool_max_tasks;
    int enable_menu_reorder;
    
    // Preload matrices at startup
    char preload_files[CONFIG_MAX_PRELOAD][256];
    int preload_count;
    
    // Menu order customization
    // Array of menu option numbers in desired display order
    // Default: {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}
    // Example custom: {10,11,12,1,2,3,4,5,6,7,8,9,13,14,15} (operations first)
    int menu_order[CONFIG_MAX_MENU_ITEMS];
    int menu_order_count;
} AppConfig;

/* Load config from a simple key=value text file.
 * Recognized keys:
 *   matrix_dir=/path/to/matrices
 *   pool_size=4
 *   pool_idle_sec=60
 *   pool_max_tasks=1000
 *   enable_menu_reorder=0
 *   menu_order=10,11,12,1,2,3,4,5,6,7,8,9,13,14,15
 *   preload=Matrix_A.txt
 *   preload=Matrix_B.txt
 *   (you can have multiple preload lines)
 */
int load_config(const char* path, AppConfig* cfg);

/* Set default values */
void set_default_config(AppConfig* cfg);

#endif // CONFIG_H
